package com.project.Studentportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
