package com.project.Studentportal.model;


import jakarta.persistence.*;

import java.util.List;



@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String password;
    private String name;
    private String address;
    private String mobile;
    private String email;
    private String attendance;
    private String currentSemester;
    private String remarks;

    @ElementCollection
    private List<String> completedCourses;

    @ElementCollection
    private List<String> achievements;

    @ElementCollection
    private List<String> backlogs;

    // Default constructor
    public Student() {}

    // Parameterized constructor
    public Student(String username, String password, String name, String address, String mobile, String email, String attendance, List<String> completedCourses, List<String> achievements, List<String> backlogs, String currentSemester, String remarks) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.address = address;
        this.mobile = mobile;
        this.email = email;
        this.attendance = attendance;
        this.completedCourses = completedCourses;
        this.achievements = achievements;
        this.backlogs = backlogs;
        this.currentSemester = currentSemester;
        this.remarks = remarks;
    }

    // Getters and Setters

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }

    public List<String> getCompletedCourses() {
        return completedCourses;
    }

    public void setCompletedCourses(List<String> completedCourses) {
        this.completedCourses = completedCourses;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCurrentSemester() {
        return currentSemester;
    }

    public void setCurrentSemester(String currentSemester) {
        this.currentSemester = currentSemester;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public List<String> getAchievements() {
        return achievements;
    }

    public void setAchievements(List<String> achievements) {
        this.achievements = achievements;
    }

    public List<String> getBacklogs() {
        return backlogs;
    }

    public void setBacklogs(List<String> backlogs) {
        this.backlogs = backlogs;
    }
}

