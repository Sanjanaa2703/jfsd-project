package com.project.Studentportal.service;
import com.project.Studentportal.model.Student;
import com.project.Studentportal.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.List;


@Service
public class Studentservice {
    @Autowired
    private StudentRepository studentRepository;

    public Student getStudentByUsername(String username) {
        return studentRepository.findByUsername(username);
    }

    public void saveStudent(Student student) {
        studentRepository.save(student);
    }

    public Student findById(Long id) {
        Optional<Student> student = studentRepository.findById(id);
        return student.orElse(null);
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
}

