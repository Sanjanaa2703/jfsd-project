package com.project.Studentportal.repository;


import com.project.Studentportal.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;


public interface StudentRepository extends JpaRepository<Student, Long> {
    Student findByUsername(String username);

}
