package com.project.Studentportal.controller;

import com.project.Studentportal.model.Admin;
import com.project.Studentportal.model.Student;
import com.project.Studentportal.service.AdminService;
import com.project.Studentportal.service.Studentservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;





@Controller
public class StudentController {
    @Autowired
    private Studentservice studentService;

    @Autowired
    private AdminService adminService;

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("error", false);
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String role, @RequestParam String username, @RequestParam String password, Model model) {
        if ("admin".equals(role)) {
            Admin admin = adminService.getAdminByUsername(username);
            if (admin != null && admin.getPassword().equals(password)) {
                model.addAttribute("admin", admin);
                model.addAttribute("students", studentService.getAllStudents());
                return "admin-dashboard";
            }
        } else if ("student".equals(role)) {
            Student student = studentService.getStudentByUsername(username);
            if (student != null && student.getPassword().equals(password)) {
                model.addAttribute("student", student);
                return "dashboard";
            }
        }
        model.addAttribute("error", true);
        return "login";
    }

    @GetMapping("/profile")
    public String profile(@RequestParam("username") String username, Model model) {
        Student student = studentService.getStudentByUsername(username);
        if (student != null) {
            model.addAttribute("student", student);
            return "profile";
        }
        return "dashboard"; // redirect to dashboard if user not found
    }

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam("username") String username, Model model) {
        Student student = studentService.getStudentByUsername(username);
        if (student != null) {
            model.addAttribute("student", student);
            return "dashboard";
        }
        return "login"; // redirect to login if user not found
    }

    @PostMapping("/update-profile")
    public String updateProfile(@RequestParam Long id, @RequestParam String name, @RequestParam String address,
                                @RequestParam String mobile, @RequestParam String email, Model model) {
        Student student = studentService.findById(id);
        if (student != null) {
            student.setName(name);
            student.setAddress(address);
            student.setMobile(mobile);
            student.setEmail(email);
            studentService.saveStudent(student);
            model.addAttribute("student", student);
        }
        return "profile";
    }

    @GetMapping("/logout")
    public String logout() {
        return "redirect:/login";
    }
}
