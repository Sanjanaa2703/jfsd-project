package com.project.Studentportal.controller;


import com.project.Studentportal.model.Admin;
import com.project.Studentportal.model.Student;
import com.project.Studentportal.service.AdminService;
import com.project.Studentportal.service.Studentservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController {
    @Autowired
    private AdminService adminService;

    @Autowired
    private Studentservice studentService;

    @GetMapping("/admin/login")
    public String adminLogin(Model model) {
        model.addAttribute("error", false);
        return "admin-login";
    }

    @PostMapping("/admin/login")
    public String adminLogin(@RequestParam String username, @RequestParam String password, Model model) {
        Admin admin = adminService.getAdminByUsername(username);
        if (admin != null && admin.getPassword().equals(password)) {
            model.addAttribute("admin", admin);
            model.addAttribute("students", studentService.getAllStudents());
            return "admin-dashboard";
        }
        model.addAttribute("error", true);
        return "admin-login";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model) {
        model.addAttribute("students", studentService.getAllStudents());
        return "admin-dashboard";
    }

    @GetMapping("/admin/edit-student")
    public String editStudent(@RequestParam Long id, Model model) {
        Student student = studentService.findById(id);
        if (student != null) {
            model.addAttribute("student", student);
            return "admin-edit-student";
        }
        return "admin-dashboard"; // redirect to dashboard if student not found
    }

    @PostMapping("/admin/update-student")
    public String updateStudent(@RequestParam Long id, @RequestParam String name, @RequestParam String address,
                                @RequestParam String mobile, @RequestParam String email, @RequestParam String attendance,
                                @RequestParam String currentSemester, @RequestParam String remarks, Model model) {
        Student student = studentService.findById(id);
        if (student != null) {
            student.setName(name);
            student.setAddress(address);
            student.setMobile(mobile);
            student.setEmail(email);
            student.setAttendance(attendance);
            student.setCurrentSemester(currentSemester);
            student.setRemarks(remarks);
            studentService.saveStudent(student);
            model.addAttribute("students", studentService.getAllStudents());
        }
        return "admin-dashboard";
    }

    @GetMapping("/admin/logout")
    public String adminLogout() {
        return "redirect:/login";
    }
}
