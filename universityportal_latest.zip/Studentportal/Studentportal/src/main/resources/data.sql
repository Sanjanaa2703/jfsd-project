INSERT INTO student (username, password, name, address, mobile, email, attendance, current_semester, remarks) VALUES
('john_doe', 'password123', 'John Doe', '123 Main St, Anytown, USA', '123-456-7890', 'john.doe@example.com', '95%', '5th Semester', 'Excellent performance'),
('jane_smith', 'password123', 'Jane Smith', '456 Oak St, Anytown, USA', '234-567-8901', 'jane.smith@example.com', '90%', '4th Semester', 'Good progress'),
('alice_johnson', 'password123', 'Alice Johnson', '789 Pine St, Anytown, USA', '345-678-9012', 'alice.johnson@example.com', '85%', '3rd Semester', 'Satisfactory'),
('bob_williams', 'password123', 'Bob Williams', '101 Maple St, Anytown, USA', '456-789-0123', 'bob.williams@example.com', '80%', '2nd Semester', 'Needs improvement'),
('carol_brown', 'password123', 'Carol Brown', '202 Elm St, Anytown, USA', '567-890-1234', 'carol.brown@example.com', '75%', '1st Semester', 'Excellent start'),
('dave_jones', 'password123', 'Dave Jones', '303 Cedar St, Anytown, USA', '678-901-2345', 'dave.jones@example.com', '70%', '6th Semester', 'Steady progress'),
('eva_miller', 'password123', 'Eva Miller', '404 Birch St, Anytown, USA', '789-012-3456', 'eva.miller@example.com', '65%', '7th Semester', 'Focus on key areas'),
('frank_moore', 'password123', 'Frank Moore', '505 Spruce St, Anytown, USA', '890-123-4567', 'frank.moore@example.com', '60%', '8th Semester', 'Final push required'),
('grace_lee', 'password123', 'Grace Lee', '606 Cherry St, Anytown, USA', '901-234-5678', 'grace.lee@example.com', '55%', '3rd Semester', 'Regular follow-up needed'),
('henry_white', 'password123', 'Henry White', '707 Walnut St, Anytown, USA', '012-345-6789', 'henry.white@example.com', '50%', '2nd Semester', 'Special attention needed');

INSERT INTO admin (username, password) VALUES
('admin1', 'adminpassword1'),
('admin2', 'adminpassword2');

INSERT INTO student_completed_courses (student_id, completed_courses) VALUES
(1, 'Math 101'),
(1, 'Science 101'),
(2, 'Math 101'),
(2, 'English 101'),
(3, 'History 101'),
(3, 'Science 101'),
(4, 'Math 101'),
(4, 'History 101'),
(5, 'Math 101'),
(5, 'Science 101'),
(6, 'Math 101'),
(7, 'Science 101'),
(8, 'History 101'),
(9, 'Math 101'),
(10, 'Science 101');

INSERT INTO student_achievements (student_id, achievements) VALUES
(1, 'Won Math Olympiad'),
(2, 'Top Scorer in English'),
(3, 'Science Fair Winner'),
(4, 'History Bee Champion'),
(5, 'Math Club Leader'),
(6, 'Best Attendance'),
(7, 'Science Quiz Winner'),
(8, 'History Club President'),
(9, 'Math Tutor'),
(10, 'Science Lab Assistant');

INSERT INTO student_backlogs (student_id, backlogs) VALUES
(1, 'None'),
(2, 'Math 102'),
(3, 'English 101'),
(4, 'Physics 101'),
(5, 'None'),
(6, 'Chemistry 101'),
(7, 'Biology 101'),
(8, 'History 102'),
(9, 'Math 102'),
(10, 'English 102');
