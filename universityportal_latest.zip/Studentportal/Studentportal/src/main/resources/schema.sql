CREATE TABLE student (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    mobile VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    attendance VARCHAR(10) NOT NULL,
    current_semester VARCHAR(50) NOT NULL,
    remarks VARCHAR(255) NOT NULL
);

CREATE TABLE admin (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);

CREATE TABLE student_completed_courses (
    student_id BIGINT NOT NULL,
    completed_courses VARCHAR(100) NOT NULL,
    FOREIGN KEY (student_id) REFERENCES student(id)
);

CREATE TABLE student_achievements (
    student_id BIGINT NOT NULL,
    achievements VARCHAR(100) NOT NULL,
    FOREIGN KEY (student_id) REFERENCES student(id)
);

CREATE TABLE student_backlogs (
    student_id BIGINT NOT NULL,
    backlogs VARCHAR(100) NOT NULL,
    FOREIGN KEY (student_id) REFERENCES student(id)
);
